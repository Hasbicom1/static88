# Railway Deployment Guide for Agent.sys

## Prerequisites
1. Railway account (https://railway.app)
2. Convex deployment URL
3. GitHub repository with the code

## Deployment Steps

### 1. Create Railway Project
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login to Railway
railway login

# Create new project
railway new
```

### 2. Set Environment Variables
In Railway dashboard, set these environment variables:

**Main App Service:**
- `NODE_ENV=production`
- `PORT=3000`
- `BROWSER_SERVICE_URL=http://browser-service:3001`
- `CONVEX_DEPLOYMENT=your-convex-deployment-name`
- `VITE_CONVEX_URL=https://your-convex-deployment.convex.cloud`

**Browser Service:**
- `NODE_ENV=production`
- `BROWSER_HEADLESS=true`
- `DATA_DIR=/data`
- `BROWSER_SERVICE_PORT=3001`

### 3. Deploy Services

**Option A: Single Service (Recommended for Railway)**
Deploy as a single service with internal communication:

```bash
# Deploy main app with browser service
railway up
```

**Option B: Separate Services**
If you need separate services:

1. Deploy browser service first:
```bash
railway up --dockerfile Dockerfile.browser
```

2. Deploy main app:
```bash
railway up --dockerfile Dockerfile
```

### 4. Configure Internal Networking
- Railway automatically handles internal service communication
- Services can communicate using service names as hostnames
- No additional networking configuration needed

### 5. Health Checks
Both services include health check endpoints:
- Main app: `GET /health`
- Browser service: `GET /health`

### 6. Monitoring
- Check Railway dashboard for logs and metrics
- Monitor browser service memory usage (Playwright can be memory-intensive)
- Set up alerts for service health

## Production Considerations

### Memory Limits
- Browser service needs at least 1GB RAM
- Main app needs at least 512MB RAM
- Consider upgrading Railway plan for production workloads

### Storage
- Browser service uses ephemeral storage for screenshots/logs
- Consider external storage for persistent data

### Security
- All browser sessions are isolated
- No persistent data storage by default
- Automatic session cleanup after 5 minutes of inactivity

### Scaling
- Browser service is stateful (maintains browser sessions)
- Horizontal scaling requires session affinity
- Consider vertical scaling for better performance

## Troubleshooting

### Common Issues
1. **Browser service fails to start**: Check memory limits
2. **Internal communication fails**: Verify service names and ports
3. **Playwright installation fails**: Ensure sufficient disk space

### Debug Commands
```bash
# Check service logs
railway logs

# Connect to service shell
railway shell

# Check service status
railway status
```

## Cost Optimization
- Use Railway's sleep feature for development
- Monitor usage and upgrade plan as needed
- Consider caching strategies for frequent operations
