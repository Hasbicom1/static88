# Stripe Setup Instructions

## 1. Create Stripe Account
1. Go to https://stripe.com and create an account
2. Complete account verification
3. Navigate to the Dashboard

## 2. Get API Keys
1. Go to **Developers** → **API keys**
2. Copy the **Publishable key** (starts with `pk_test_`)
3. Copy the **Secret key** (starts with `sk_test_`)

## 3. Set Environment Variables

### For Development (.env.local):
```bash
STRIPE_SECRET_KEY=sk_test_your_secret_key_here
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key_here
```

### For Railway Deployment:
```bash
railway variables set STRIPE_SECRET_KEY=sk_test_your_secret_key_here
railway variables set VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key_here
```

## 4. Set Up Webhooks (Optional but Recommended)

1. Go to **Developers** → **Webhooks**
2. Click **Add endpoint**
3. Set endpoint URL: `https://your-app.railway.app/api/webhooks/stripe`
4. Select events to listen for:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
5. Copy the **Signing secret** (starts with `whsec_`)
6. Add to environment variables:
   ```bash
   STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret_here
   ```

## 5. Test Cards

Use these test card numbers in development:

- **Success**: 4242 4242 4242 4242
- **Decline**: 4000 0000 0000 0002
- **Insufficient funds**: 4000 0000 0000 9995
- **Expired card**: 4000 0000 0000 0069

Use any future expiry date and any 3-digit CVC.

## 6. Production Setup

For production:
1. Complete Stripe account activation
2. Replace test keys with live keys (starts with `pk_live_` and `sk_live_`)
3. Update webhook endpoint to production URL
4. Test with real payment methods

## 7. Verify Setup

After setting up environment variables:
1. Restart your development server
2. Try the payment flow
3. Check Stripe Dashboard for test payments
4. Verify webhook events are received (if configured)
