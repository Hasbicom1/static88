import { cronJobs } from "convex/server";
import { internal } from "./_generated/api";
import { internalMutation } from "./_generated/server";

const crons = cronJobs();

// Clean up expired agents every hour
crons.interval("cleanup expired agents", { hours: 1 }, internal.crons.cleanupExpiredAgents, {});

export const cleanupExpiredAgents = internalMutation({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    
    // Find all expired agents
    const expiredAgents = await ctx.db
      .query("agents")
      .withIndex("by_status", (q) => q.eq("status", "active"))
      .filter((q) => q.lt(q.field("expiresAt"), now))
      .collect();

    // Mark them as expired
    for (const agent of expiredAgents) {
      await ctx.db.patch(agent._id, {
        status: "expired",
      });
      
      console.log(`Expired agent: ${agent.sessionId}`);
    }

    return { expiredCount: expiredAgents.length };
  },
});

export default crons;
