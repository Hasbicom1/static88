# 🚀 Agent.sys - Railway Deployment Guide

## Complete Playwright Browser Automation System

This system provides a production-ready AI-powered browser automation platform with:
- **Real browser control** via Playwright
- **AI task execution** with GPT integration  
- **Secure payment processing** via Stripe
- **24-hour agent sessions** with automatic cleanup
- **Live browser screenshots** and monitoring

## 🏗️ Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Convex API     │    │ Browser Service │
│   (React/Vite)  │◄──►│   (Functions)    │◄──►│  (Playwright)   │
│   Port: 3000    │    │   (Database)     │    │   Port: 3001    │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## 🚀 Quick Deploy to Railway

### 1. Prerequisites
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login to Railway
railway login
```

### 2. Deploy with One Command
```bash
# Clone and deploy
git clone <your-repo>
cd agent-sys
chmod +x railway-setup.sh
./railway-setup.sh
```

### 3. Set Environment Variables
The deployment script automatically sets:
- `CONVEX_DEPLOYMENT=successful-ladybug-912`
- `VITE_CONVEX_URL=https://successful-ladybug-912.convex.cloud`
- `BROWSER_SERVICE_URL=http://browser-service:3001`
- `BROWSER_HEADLESS=true`

## 🔧 Manual Deployment

### Step 1: Create Railway Project
```bash
railway new agent-sys-browser-automation
```

### Step 2: Configure Environment
```bash
railway variables set NODE_ENV=production
railway variables set PORT=3000
railway variables set BROWSER_SERVICE_URL=http://browser-service:3001
railway variables set CONVEX_DEPLOYMENT=successful-ladybug-912
railway variables set VITE_CONVEX_URL=https://successful-ladybug-912.convex.cloud
railway variables set BROWSER_HEADLESS=true
railway variables set DATA_DIR=/data
railway variables set BROWSER_SERVICE_PORT=3001
```

### Step 3: Deploy
```bash
railway up
```

## ✅ Verification

After deployment, test these endpoints:

### Health Checks
```bash
# Main app health
curl https://your-app.railway.app/health

# Browser service status  
curl https://your-app.railway.app/api/browser/status
```

### Browser Automation Test
```bash
# Initialize browser session
curl -X POST https://your-app.railway.app/api/browser/init \
  -H "Content-Type: application/json" \
  -d '{"sessionId": "test-session"}'

# Navigate to website
curl -X POST https://your-app.railway.app/api/browser/navigate \
  -H "Content-Type: application/json" \
  -d '{"sessionId": "test-session", "url": "https://example.com"}'

# Take screenshot
curl -X POST https://your-app.railway.app/api/browser/screenshot \
  -H "Content-Type: application/json" \
  -d '{"sessionId": "test-session"}'
```

## 📊 Production Monitoring

### Resource Requirements
- **Main App**: 512MB RAM, 1 CPU
- **Browser Service**: 1GB+ RAM, 1 CPU
- **Storage**: 1GB for screenshots/logs

### Key Metrics to Monitor
- Browser session count
- Memory usage (Playwright is memory-intensive)
- Response times for browser operations
- Session cleanup frequency

### Logs to Watch
```bash
# View Railway logs
railway logs

# Monitor browser service specifically
railway logs --service browser-service
```

## 🔒 Security Features

- **Isolated browser sessions** - Each user gets isolated context
- **Automatic cleanup** - Sessions expire after 5 minutes of inactivity  
- **No persistent storage** - Screenshots/logs are ephemeral
- **Stripe payments** - Secure payment processing
- **HTTPS everywhere** - Railway provides automatic SSL

## 🎯 API Endpoints

### Browser Control
- `POST /api/browser/init` - Initialize browser session
- `POST /api/browser/navigate` - Navigate to URL
- `POST /api/browser/click` - Click element
- `POST /api/browser/type` - Type text
- `POST /api/browser/screenshot` - Take screenshot
- `POST /api/browser/close` - Close session

### System Health
- `GET /health` - Main app health check
- `GET /api/browser/status` - Browser service status

## 🚨 Troubleshooting

### Common Issues

**Browser service fails to start:**
- Check memory limits (needs 1GB+)
- Verify Playwright installation
- Check disk space for browser downloads

**Internal communication fails:**
- Verify `BROWSER_SERVICE_URL` environment variable
- Check service networking configuration
- Ensure both services are running

**High memory usage:**
- Monitor concurrent browser sessions
- Check session cleanup intervals
- Consider vertical scaling

### Debug Commands
```bash
# Check service status
railway status

# View detailed logs
railway logs --tail

# Connect to service shell
railway shell
```

## 💰 Cost Optimization

### Railway Pricing
- **Hobby Plan**: $5/month - Good for development
- **Pro Plan**: $20/month - Recommended for production
- **Usage-based**: Pay for actual resource consumption

### Optimization Tips
- Enable sleep mode for development environments
- Monitor and optimize browser session duration
- Use efficient Playwright selectors
- Implement proper session cleanup

## 📞 Support

- **Railway Support**: https://railway.app/help
- **Convex Support**: support@convex.dev  
- **Playwright Issues**: https://github.com/microsoft/playwright/issues

## 🎉 Success!

Your Agent.sys browser automation platform is now deployed and ready for production use!

**Next Steps:**
1. Test the payment flow with Stripe
2. Configure monitoring and alerts
3. Set up custom domain (optional)
4. Scale resources based on usage

**Dashboard URLs:**
- **App**: https://your-app.railway.app
- **Railway Dashboard**: https://railway.app/dashboard
- **Convex Dashboard**: https://dashboard.convex.dev/d/successful-ladybug-912
