import { useState, useEffect } from "react";
import { useMutation, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  CardElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";

// Initialize Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || "pk_test_placeholder");

interface PaymentModalProps {
  onClose: () => void;
}

function PaymentForm({ onClose }: PaymentModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [clientSecret, setClientSecret] = useState<string>("");
  const [paymentId, setPaymentId] = useState<string>("");
  
  const stripe = useStripe();
  const elements = useElements();
  
  const createPaymentIntent = useAction(api.stripe.createPaymentIntent);
  const confirmPayment = useAction(api.stripe.confirmPayment);
  const createAgent = useMutation(api.agents.createAgent);

  useEffect(() => {
    // Check if Stripe is configured
    const stripeKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY;
    if (!stripeKey || stripeKey === "pk_test_placeholder") {
      toast.error("⚠️ Stripe not configured! Please add your Stripe keys to .env.local");
      return;
    }

    // Initialize payment intent when modal opens
    const initPayment = async () => {
      try {
        const { clientSecret, paymentId } = await createPaymentIntent();
        setClientSecret(clientSecret || "");
        setPaymentId(paymentId);
      } catch (error) {
        console.error("Payment initialization error:", error);
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        
        if (errorMessage.includes("STRIPE_SECRET_KEY")) {
          toast.error("🔑 Add STRIPE_SECRET_KEY to Convex Dashboard Environment Variables");
        } else {
          toast.error(`Payment failed: ${errorMessage}`);
        }
      }
    };
    initPayment();
  }, [createPaymentIntent]);

  const handlePayment = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements || !clientSecret) {
      toast.error("Payment system not ready");
      return;
    }

    const cardElement = elements.getElement(CardElement);
    if (!cardElement) {
      toast.error("Card element not found");
      return;
    }

    setIsProcessing(true);
    try {
      // Confirm payment with Stripe
      const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement,
        },
      });

      if (error) {
        throw new Error(error.message);
      }

      if (paymentIntent?.status === "succeeded") {
        // Confirm payment with our backend
        await confirmPayment({ paymentId });
        
        // Create agent session
        await createAgent({ paymentId });
        
        toast.success("🚀 Agent deployed successfully!");
        onClose();
      } else {
        throw new Error("Payment was not successful");
      }
    } catch (error) {
      console.error('Payment error:', error);
      toast.error(error instanceof Error ? error.message : "Payment failed. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const cardElementOptions = {
    style: {
      base: {
        fontSize: '16px',
        color: '#00ff00',
        backgroundColor: '#111827',
        fontFamily: 'JetBrains Mono, monospace',
        padding: '16px',
        '::placeholder': {
          color: '#00ff0080',
        },
        iconColor: '#00ff00',
      },
      invalid: {
        color: '#ff0000',
        iconColor: '#ff0000',
      },
      complete: {
        color: '#00ff00',
        iconColor: '#00ff00',
      },
    },
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="terminal-window max-w-lg w-full">
        <div className="terminal-header">
          <div className="flex space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          </div>
          <span className="text-sm">stripe-payment.exe</span>
          <button onClick={onClose} className="text-red-400 hover:text-red-300 text-xl">×</button>
        </div>
        
        <div className="terminal-body space-y-6">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-cyan-400 mb-2">DEPLOY AI AGENT</h3>
            <p className="text-green-300">24 Hour Browser Automation Access</p>
            <div className="flex justify-center items-center space-x-2 mt-2">
              <span className="text-xs text-green-300/60">Powered by</span>
              <img 
                src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjQiIGhlaWdodD0iMjYiIHZpZXdCb3g9IjAgMCA2NCAyNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTI2LjQgMTMuNkMyNi40IDEwLjggMjQuOCA4LjggMjIuNCA4LjhDMjAgOC44IDE4LjQgMTAuOCAxOC40IDEzLjZDMTguNCAxNi40IDIwIDE4LjQgMjIuNCAxOC40QzI0LjggMTguNCAyNi40IDE2LjQgMjYuNCAxMy42WiIgZmlsbD0iIzYzNzJGRiIvPgo8cGF0aCBkPSJNNDAuOCA5SDM4LjRWMTguMkgzNS42VjlIMzMuMlY2LjZIMzUuNlY0LjJIMzguNFY2LjZINDAuOFY5WiIgZmlsbD0iIzYzNzJGRiIvPgo8cGF0aCBkPSJNNTIuOCA5SDUwLjRWMTguMkg0Ny42VjlINDUuMlY2LjZINDcuNlY0LjJINTAuNFY2LjZINTIuOFY5WiIgZmlsbD0iIzYzNzJGRiIvPgo8cGF0aCBkPSJNNjQgOUg2MS42VjE4LjJINTguOFY5SDU2LjRWNi42SDU4LjhWNC4ySDYxLjZWNi42SDY0VjlaIiBmaWxsPSIjNjM3MkZGIi8+CjxwYXRoIGQ9Ik0xNC40IDlIMTJWMTguMkg5LjJWOUg2LjhWNi42SDkuMlY0LjJIMTJWNi42SDE0LjRWOVoiIGZpbGw9IiM2MzcyRkYiLz4KPHBhdGggZD0iTTIuNCA5SDBWMTguMkgwVjZIMi40VjlaIiBmaWxsPSIjNjM3MkZGIi8+Cjwvc3ZnPgo=" 
                alt="Stripe" 
                className="h-5"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="payment-summary">
              <div className="flex justify-between items-center p-4 border border-green-400/30 rounded bg-green-400/5">
                <div>
                  <div className="font-bold text-green-400">AI Browser Agent</div>
                  <div className="text-sm text-green-300/80">24 hours unlimited access</div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-cyan-400">$1.00</div>
                  <div className="text-xs text-green-300/60">USD</div>
                </div>
              </div>
            </div>
            
            <div className="features-list space-y-2 text-sm">
              <div className="flex items-center space-x-2 text-green-300">
                <span className="text-green-400">✓</span>
                <span>Real Chrome browser automation</span>
              </div>
              <div className="flex items-center space-x-2 text-green-300">
                <span className="text-green-400">✓</span>
                <span>AI-powered task execution</span>
              </div>
              <div className="flex items-center space-x-2 text-green-300">
                <span className="text-green-400">✓</span>
                <span>Live screenshots & monitoring</span>
              </div>
              <div className="flex items-center space-x-2 text-green-300">
                <span className="text-green-400">✓</span>
                <span>Unlimited tasks for 24 hours</span>
              </div>
              <div className="flex items-center space-x-2 text-green-300">
                <span className="text-green-400">✓</span>
                <span>Secure isolated sessions</span>
              </div>
            </div>
          </div>

          <form onSubmit={handlePayment} className="payment-form space-y-4">
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-green-300 mb-2">Card Details</label>
                <div className="bg-gray-900 border-2 border-green-400 rounded-lg p-4 min-h-[50px] flex items-center">
                  <CardElement options={cardElementOptions} />
                </div>
                <div className="text-xs text-green-300/60 mt-2 p-2 bg-green-400/10 rounded border border-green-400/20">
                  <div className="font-bold text-green-400 mb-1">Test Card Details:</div>
                  <div>Card: 4242 4242 4242 4242</div>
                  <div>Expiry: Any future date (e.g., 12/25)</div>
                  <div>CVC: Any 3 digits (e.g., 123)</div>
                </div>
              </div>
            </div>

            <div className="security-badges flex justify-center space-x-4 text-xs text-green-300/60">
              <div className="flex items-center space-x-1">
                <span>🔒</span>
                <span>SSL Encrypted</span>
              </div>
              <div className="flex items-center space-x-1">
                <span>🛡️</span>
                <span>PCI Compliant</span>
              </div>
              <div className="flex items-center space-x-1">
                <span>✅</span>
                <span>Stripe Secure</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isProcessing || !stripe || !clientSecret}
              className="cyber-button w-full"
            >
              <span className="button-text">
                {isProcessing ? (
                  <span className="flex items-center justify-center space-x-2">
                    <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                    <span>PROCESSING...</span>
                  </span>
                ) : (
                  <span className="flex items-center justify-center space-x-2">
                    <span>🚀 DEPLOY AGENT</span>
                    <span>$1.00</span>
                  </span>
                )}
              </span>
              <div className="button-glow"></div>
            </button>

            <div className="text-center text-xs text-green-300/60">
              By proceeding, you agree to our Terms of Service.<br/>
              Your agent will be deployed instantly after payment confirmation.
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export function PaymentModal({ onClose }: PaymentModalProps) {
  return (
    <Elements stripe={stripePromise}>
      <PaymentForm onClose={onClose} />
    </Elements>
  );
}
