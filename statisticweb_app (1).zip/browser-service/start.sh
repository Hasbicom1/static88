#!/bin/bash

# Browser Service Startup Script
echo "🌐 Starting Browser Automation Service..."

# Create data directories
mkdir -p /data/screenshots /data/logs

# Install Playwright browsers if not already installed
if [ ! -d "/root/.cache/ms-playwright" ]; then
    echo "📦 Installing Playwright browsers..."
    npx playwright install chromium
fi

# Start the service
echo "🚀 Starting browser service on port $BROWSER_SERVICE_PORT..."
node server.js
