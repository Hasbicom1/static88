// Deployment verification script
async function verifyDeployment(baseUrl) {
  console.log(`🔍 Verifying deployment at ${baseUrl}...`);
  
  try {
    // Test main app health
    console.log('1. Testing main app health...');
    const healthResponse = await fetch(`${baseUrl}/health`);
    const healthData = await healthResponse.json();
    console.log('✅ Main app health:', healthData);

    // Test browser service status via proxy
    console.log('2. Testing browser service status...');
    const statusResponse = await fetch(`${baseUrl}/api/browser/status`);
    const statusData = await statusResponse.json();
    console.log('✅ Browser service status:', statusData);

    // Test Convex connection
    console.log('3. Testing Convex connection...');
    // This would require authentication, so we'll skip for now
    console.log('⏭️  Skipping Convex test (requires auth)');

    console.log('🎉 Deployment verification completed!');
    return true;
    
  } catch (error) {
    console.error('❌ Verification failed:', error.message);
    return false;
  }
}

// Usage: node verify-deployment.js https://your-app.railway.app
const url = process.argv[2];
if (url) {
  verifyDeployment(url);
} else {
  console.log('Usage: node verify-deployment.js <deployment-url>');
}
