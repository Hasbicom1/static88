import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { chromium } from 'playwright';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.BROWSER_SERVICE_PORT || 3001;
const HEADLESS = process.env.BROWSER_HEADLESS !== 'false';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');

// Middleware
app.use(helmet());
app.use(cors());
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));

// Ensure data directory exists
await fs.mkdir(DATA_DIR, { recursive: true });
await fs.mkdir(path.join(DATA_DIR, 'screenshots'), { recursive: true });
await fs.mkdir(path.join(DATA_DIR, 'logs'), { recursive: true });

// Browser session management
const activeSessions = new Map();

// Cleanup inactive sessions every 5 minutes
setInterval(async () => {
  const now = Date.now();
  for (const [sessionId, session] of activeSessions.entries()) {
    if (now - session.lastActivity > 5 * 60 * 1000) { // 5 minutes
      try {
        await session.context.close();
        activeSessions.delete(sessionId);
        console.log(`Cleaned up inactive session: ${sessionId}`);
      } catch (error) {
        console.error(`Error cleaning up session ${sessionId}:`, error);
      }
    }
  }
}, 5 * 60 * 1000);

// Helper function to get or create browser session
async function getSession(sessionId) {
  if (!activeSessions.has(sessionId)) {
    const browser = await chromium.launch({
      headless: HEADLESS,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--disable-gpu',
        '--disable-web-security',
        '--disable-features=VizDisplayCompositor'
      ]
    });

    const context = await browser.newContext({
      viewport: { width: 1920, height: 1080 },
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    });

    const page = await context.newPage();
    
    // Set up logging
    const logs = [];
    page.on('console', msg => {
      logs.push({
        type: 'console',
        level: msg.type(),
        text: msg.text(),
        timestamp: Date.now()
      });
    });

    page.on('pageerror', error => {
      logs.push({
        type: 'error',
        text: error.message,
        timestamp: Date.now()
      });
    });

    const session = {
      browser,
      context,
      page,
      logs,
      lastActivity: Date.now(),
      createdAt: Date.now()
    };

    activeSessions.set(sessionId, session);
    console.log(`Created new browser session: ${sessionId}`);
  }

  const session = activeSessions.get(sessionId);
  session.lastActivity = Date.now();
  return session;
}

// Helper function to take screenshot
async function takeScreenshot(page, sessionId) {
  const screenshotId = uuidv4();
  const screenshotPath = path.join(DATA_DIR, 'screenshots', `${sessionId}_${screenshotId}.png`);
  
  const screenshot = await page.screenshot({
    path: screenshotPath,
    fullPage: false,
    type: 'png'
  });

  return {
    id: screenshotId,
    path: screenshotPath,
    base64: screenshot.toString('base64'),
    timestamp: Date.now()
  };
}

// Helper function to save logs
async function saveLogs(sessionId, logs) {
  const logPath = path.join(DATA_DIR, 'logs', `${sessionId}.json`);
  await fs.writeFile(logPath, JSON.stringify(logs, null, 2));
}

// API Routes

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    activeSessions: activeSessions.size,
    timestamp: Date.now()
  });
});

// Initialize browser session
app.post('/api/browser/init', async (req, res) => {
  try {
    const { sessionId = uuidv4() } = req.body;
    const session = await getSession(sessionId);
    
    // Navigate to default page
    await session.page.goto('https://www.google.com', { waitUntil: 'networkidle' });
    
    const screenshot = await takeScreenshot(session.page, sessionId);
    
    res.json({
      success: true,
      sessionId,
      screenshot: `data:image/png;base64,${screenshot.base64}`,
      url: session.page.url(),
      title: await session.page.title()
    });
  } catch (error) {
    console.error('Browser init error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Navigate to URL
app.post('/api/browser/navigate', async (req, res) => {
  try {
    const { sessionId, url } = req.body;
    
    if (!sessionId || !url) {
      return res.status(400).json({
        success: false,
        error: 'sessionId and url are required'
      });
    }

    const session = await getSession(sessionId);
    
    await session.page.goto(url, { 
      waitUntil: 'networkidle',
      timeout: 30000 
    });
    
    const screenshot = await takeScreenshot(session.page, sessionId);
    
    res.json({
      success: true,
      screenshot: `data:image/png;base64,${screenshot.base64}`,
      url: session.page.url(),
      title: await session.page.title(),
      message: `Navigated to ${url}`
    });
  } catch (error) {
    console.error('Navigation error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Click element
app.post('/api/browser/click', async (req, res) => {
  try {
    const { sessionId, selector } = req.body;
    
    if (!sessionId || !selector) {
      return res.status(400).json({
        success: false,
        error: 'sessionId and selector are required'
      });
    }

    const session = await getSession(sessionId);
    
    await session.page.waitForSelector(selector, { timeout: 10000 });
    await session.page.click(selector);
    await session.page.waitForTimeout(1000); // Wait for any animations
    
    const screenshot = await takeScreenshot(session.page, sessionId);
    
    res.json({
      success: true,
      screenshot: `data:image/png;base64,${screenshot.base64}`,
      url: session.page.url(),
      message: `Clicked element: ${selector}`
    });
  } catch (error) {
    console.error('Click error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Type text
app.post('/api/browser/type', async (req, res) => {
  try {
    const { sessionId, selector, text } = req.body;
    
    if (!sessionId || !selector || text === undefined) {
      return res.status(400).json({
        success: false,
        error: 'sessionId, selector, and text are required'
      });
    }

    const session = await getSession(sessionId);
    
    await session.page.waitForSelector(selector, { timeout: 10000 });
    await session.page.click(selector);
    await session.page.keyboard.press('Control+KeyA');
    await session.page.fill(selector, text);
    
    const screenshot = await takeScreenshot(session.page, sessionId);
    
    res.json({
      success: true,
      screenshot: `data:image/png;base64,${screenshot.base64}`,
      url: session.page.url(),
      message: `Typed "${text}" into ${selector}`
    });
  } catch (error) {
    console.error('Type error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Extract text
app.post('/api/browser/extract', async (req, res) => {
  try {
    const { sessionId, selector } = req.body;
    
    if (!sessionId || !selector) {
      return res.status(400).json({
        success: false,
        error: 'sessionId and selector are required'
      });
    }

    const session = await getSession(sessionId);
    
    await session.page.waitForSelector(selector, { timeout: 10000 });
    const text = await session.page.textContent(selector);
    
    const screenshot = await takeScreenshot(session.page, sessionId);
    
    res.json({
      success: true,
      text: text || '',
      screenshot: `data:image/png;base64,${screenshot.base64}`,
      url: session.page.url(),
      message: `Extracted text: ${text}`
    });
  } catch (error) {
    console.error('Extract error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Take screenshot
app.post('/api/browser/screenshot', async (req, res) => {
  try {
    const { sessionId } = req.body;
    
    if (!sessionId) {
      return res.status(400).json({
        success: false,
        error: 'sessionId is required'
      });
    }

    const session = await getSession(sessionId);
    const screenshot = await takeScreenshot(session.page, sessionId);
    
    res.json({
      success: true,
      screenshot: `data:image/png;base64,${screenshot.base64}`,
      url: session.page.url(),
      title: await session.page.title(),
      message: 'Screenshot captured successfully'
    });
  } catch (error) {
    console.error('Screenshot error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Scroll page
app.post('/api/browser/scroll', async (req, res) => {
  try {
    const { sessionId, direction = 'down', amount = 500 } = req.body;
    
    if (!sessionId) {
      return res.status(400).json({
        success: false,
        error: 'sessionId is required'
      });
    }

    const session = await getSession(sessionId);
    
    const scrollAmount = direction === 'up' ? -Math.abs(amount) : Math.abs(amount);
    await session.page.evaluate((scroll) => {
      window.scrollBy(0, scroll);
    }, scrollAmount);
    
    await session.page.waitForTimeout(500);
    const screenshot = await takeScreenshot(session.page, sessionId);
    
    res.json({
      success: true,
      screenshot: `data:image/png;base64,${screenshot.base64}`,
      url: session.page.url(),
      message: `Scrolled ${direction} by ${Math.abs(amount)}px`
    });
  } catch (error) {
    console.error('Scroll error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Execute script
app.post('/api/browser/script', async (req, res) => {
  try {
    const { sessionId, script } = req.body;
    
    if (!sessionId || !script) {
      return res.status(400).json({
        success: false,
        error: 'sessionId and script are required'
      });
    }

    const session = await getSession(sessionId);
    
    const result = await session.page.evaluate((script) => {
      return eval(script);
    }, script);
    
    const screenshot = await takeScreenshot(session.page, sessionId);
    
    res.json({
      success: true,
      result: JSON.stringify(result),
      screenshot: `data:image/png;base64,${screenshot.base64}`,
      url: session.page.url(),
      message: `Script executed: ${script}`
    });
  } catch (error) {
    console.error('Script execution error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get browser status
app.post('/api/browser/status', async (req, res) => {
  try {
    const { sessionId } = req.body;
    
    if (!sessionId) {
      return res.status(400).json({
        success: false,
        error: 'sessionId is required'
      });
    }

    const session = activeSessions.get(sessionId);
    
    if (!session) {
      return res.status(404).json({
        success: false,
        error: 'Session not found'
      });
    }

    res.json({
      success: true,
      url: session.page.url(),
      title: await session.page.title(),
      lastActivity: session.lastActivity,
      createdAt: session.createdAt,
      logsCount: session.logs.length
    });
  } catch (error) {
    console.error('Status error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get session logs
app.get('/api/browser/logs/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const session = activeSessions.get(sessionId);
    
    if (!session) {
      return res.status(404).json({
        success: false,
        error: 'Session not found'
      });
    }

    await saveLogs(sessionId, session.logs);
    
    res.json({
      success: true,
      logs: session.logs,
      count: session.logs.length
    });
  } catch (error) {
    console.error('Logs error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Close session
app.post('/api/browser/close', async (req, res) => {
  try {
    const { sessionId } = req.body;
    
    if (!sessionId) {
      return res.status(400).json({
        success: false,
        error: 'sessionId is required'
      });
    }

    const session = activeSessions.get(sessionId);
    
    if (session) {
      await saveLogs(sessionId, session.logs);
      await session.context.close();
      activeSessions.delete(sessionId);
    }
    
    res.json({
      success: true,
      message: `Session ${sessionId} closed`
    });
  } catch (error) {
    console.error('Close session error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Unhandled error:', error);
  res.status(500).json({
    success: false,
    error: 'Internal server error'
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, closing browser sessions...');
  
  for (const [sessionId, session] of activeSessions.entries()) {
    try {
      await saveLogs(sessionId, session.logs);
      await session.context.close();
    } catch (error) {
      console.error(`Error closing session ${sessionId}:`, error);
    }
  }
  
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, closing browser sessions...');
  
  for (const [sessionId, session] of activeSessions.entries()) {
    try {
      await saveLogs(sessionId, session.logs);
      await session.context.close();
    } catch (error) {
      console.error(`Error closing session ${sessionId}:`, error);
    }
  }
  
  process.exit(0);
});

app.listen(PORT, () => {
  console.log(`Browser automation service running on port ${PORT}`);
  console.log(`Headless mode: ${HEADLESS}`);
  console.log(`Data directory: ${DATA_DIR}`);
});
