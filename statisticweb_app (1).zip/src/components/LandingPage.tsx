import React, { useState } from "react";
import { PaymentModal } from "./PaymentModal";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { SignInForm } from "../SignInForm";

export function LandingPage() {
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showSignIn, setShowSignIn] = useState(false);
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const userAgent = useQuery(api.agents.getUserAgent);

  // Auto-open payment modal when user signs in anonymously
  React.useEffect(() => {
    if (loggedInUser && !userAgent) {
      setShowPaymentModal(true);
    }
  }, [loggedInUser]);

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="text-center space-y-8">
        <div className="glitch-container">
          <h1 className="text-7xl font-bold glitch" data-text="AGENT.SYS">
            AGENT.SYS
          </h1>
        </div>
        
        <div className="typewriter">
          <p className="text-2xl text-green-300">
            {"> $1 AI BROWSER AGENT • 24H AUTONOMOUS AUTOMATION"}
          </p>
        </div>

        <div className="flex justify-center space-x-4 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-green-400">REAL BROWSER</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
            <span className="text-cyan-400">AI POWERED</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
            <span className="text-yellow-400">$1 ONLY</span>
          </div>
        </div>
      </div>

      {/* Feature Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {/* AI Automation Card */}
        <div className="feature-card group" data-feature="ai">
          <div className="card-header">
            <div className="flex items-center justify-between">
              <span className="text-purple-400 font-mono">[AI.CORE]</span>
              <div className="ai-indicator">
                <div className="ai-pulse"></div>
              </div>
            </div>
          </div>
          <div className="card-content">
            <div className="feature-icon">🧠</div>
            <h3 className="text-xl font-bold mb-3">AI-Powered Automation</h3>
            <p className="text-green-300/80 mb-4">
              Advanced AI understands complex web tasks and executes them autonomously
            </p>
            <div className="demo-animation ai-demo">
              <div className="code-line">agent.analyze(webpage)</div>
              <div className="code-line delay-1">agent.execute(task)</div>
              <div className="code-line delay-2 text-green-400">✓ Task completed</div>
            </div>
          </div>
          <div className="card-glow ai-glow"></div>
        </div>

        {/* Real Browser Card */}
        <div className="feature-card group" data-feature="browser">
          <div className="card-header">
            <div className="flex items-center justify-between">
              <span className="text-cyan-400 font-mono">[BROWSER.SYS]</span>
              <div className="browser-indicator">
                <div className="browser-tabs">
                  <div className="tab active"></div>
                  <div className="tab"></div>
                  <div className="tab"></div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-content">
            <div className="feature-icon">🌐</div>
            <h3 className="text-xl font-bold mb-3">Real Browser Control</h3>
            <p className="text-green-300/80 mb-4">
              Full Chrome browser automation with live screenshots and real interactions
            </p>
            <div className="demo-animation browser-demo">
              <div className="browser-window">
                <div className="address-bar">https://example.com</div>
                <div className="page-content">
                  <div className="element clicking"></div>
                  <div className="element typing"></div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-glow browser-glow"></div>
        </div>

        {/* Dollar Value Card */}
        <div className="feature-card group" data-feature="price">
          <div className="card-header">
            <div className="flex items-center justify-between">
              <span className="text-yellow-400 font-mono">[PRICE.TAG]</span>
              <div className="price-indicator">
                <span className="dollar-sign">$</span>
              </div>
            </div>
          </div>
          <div className="card-content">
            <div className="feature-icon">💰</div>
            <h3 className="text-xl font-bold mb-3">Just $1.00</h3>
            <p className="text-green-300/80 mb-4">
              24 hours of unlimited browser automation for the price of a coffee
            </p>
            <div className="demo-animation price-demo">
              <div className="value-comparison">
                <div className="comparison-item">
                  <span className="label">Traditional RPA:</span>
                  <span className="price old-price">$100+/month</span>
                </div>
                <div className="comparison-item">
                  <span className="label">Agent.sys:</span>
                  <span className="price new-price">$1/24h</span>
                </div>
                <div className="savings">99% SAVINGS!</div>
              </div>
            </div>
          </div>
          <div className="card-glow price-glow"></div>
        </div>

        {/* 24H Access Card */}
        <div className="feature-card group" data-feature="duration">
          <div className="card-header">
            <div className="flex items-center justify-between">
              <span className="text-green-400 font-mono">[TIME.SYS]</span>
              <div className="time-indicator">
                <div className="clock">
                  <div className="hour-hand"></div>
                  <div className="minute-hand"></div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-content">
            <div className="feature-icon">⏰</div>
            <h3 className="text-xl font-bold mb-3">24 Hour Access</h3>
            <p className="text-green-300/80 mb-4">
              Continuous agent availability for complex, multi-step workflows
            </p>
            <div className="demo-animation time-demo">
              <div className="timeline">
                <div className="time-block active">0h - Setup</div>
                <div className="time-block active">6h - Running</div>
                <div className="time-block active">12h - Active</div>
                <div className="time-block">24h - Complete</div>
              </div>
            </div>
          </div>
          <div className="card-glow time-glow"></div>
        </div>

        {/* Security Card */}
        <div className="feature-card group" data-feature="security">
          <div className="card-header">
            <div className="flex items-center justify-between">
              <span className="text-red-400 font-mono">[SEC.LOCK]</span>
              <div className="security-indicator">
                <div className="shield">🛡️</div>
              </div>
            </div>
          </div>
          <div className="card-content">
            <div className="feature-icon">🔒</div>
            <h3 className="text-xl font-bold mb-3">Secure & Private</h3>
            <p className="text-green-300/80 mb-4">
              Isolated browser sessions with enterprise-grade security
            </p>
            <div className="demo-animation security-demo">
              <div className="security-layers">
                <div className="layer">🔐 Encrypted Sessions</div>
                <div className="layer">🚫 No Data Storage</div>
                <div className="layer">✅ Stripe Payments</div>
              </div>
            </div>
          </div>
          <div className="card-glow security-glow"></div>
        </div>

        {/* Use Cases Card */}
        <div className="feature-card group" data-feature="usecases">
          <div className="card-header">
            <div className="flex items-center justify-between">
              <span className="text-orange-400 font-mono">[USE.CASE]</span>
              <div className="usecase-indicator">
                <div className="rotating-icon">⚡</div>
              </div>
            </div>
          </div>
          <div className="card-content">
            <div className="feature-icon">🎯</div>
            <h3 className="text-xl font-bold mb-3">Endless Possibilities</h3>
            <p className="text-green-300/80 mb-4">
              Web scraping, form filling, testing, monitoring, and more
            </p>
            <div className="demo-animation usecase-demo">
              <div className="use-cases">
                <div className="use-case">📊 Data Scraping</div>
                <div className="use-case">📝 Form Automation</div>
                <div className="use-case">🧪 Web Testing</div>
                <div className="use-case">📈 Site Monitoring</div>
              </div>
            </div>
          </div>
          <div className="card-glow usecase-glow"></div>
        </div>
      </div>

      {/* Command Line Demo */}
      <div className="terminal-window">
        <div className="terminal-header">
          <div className="flex space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          </div>
          <span className="text-sm">agent@browser:~$</span>
        </div>
        <div className="terminal-body">
          <div className="command-demo">
            <div className="command-line">
              <span className="prompt">$</span>
              <span className="command typing-animation">agent.navigate("https://example.com")</span>
            </div>
            <div className="output">
              <span className="text-cyan-400">[INFO]</span> Initializing browser session...<br/>
              <span className="text-green-400">[SUCCESS]</span> Navigation completed in 1.2s<br/>
              <span className="text-yellow-400">[READY]</span> Agent awaiting next command
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="text-center space-y-8">
        <div className="space-y-4">
          <h2 className="text-3xl font-bold text-cyan-400">Deploy Your Agent Now</h2>
          <p className="text-green-300/80 max-w-2xl mx-auto">
            Join thousands of developers automating the web with AI. 
            Secure payment powered by Stripe. No subscription, pay per use.
          </p>
        </div>

        <button
          onClick={() => {
            if (loggedInUser) {
              setShowPaymentModal(true);
            } else {
              setShowSignIn(true);
            }
          }}
          className="cyber-button-large"
        >
          <span className="button-text">
            <span className="flex items-center space-x-3">
              <span>🚀 {loggedInUser ? 'DEPLOY AGENT' : 'SIGN IN TO DEPLOY'}</span>
              <span className="text-yellow-400">$1.00</span>
              <span className="stripe-badge">
                <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iMTciIHZpZXdCb3g9IjAgMCA0MCAxNyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yNS4xIDYuOEMyNS4xIDUuNCAyNC4yIDQuNiAyMi44IDQuNkMyMS4zIDQuNiAyMC4zIDUuNCAyMC4zIDYuOEMyMC4zIDguMiAyMS4zIDkgMjIuOCA5QzI0LjIgOSAyNS4xIDguMiAyNS4xIDYuOFpNMjIuOCAxMC4yQzIwLjYgMTAuMiAxOSA4LjggMTkgNi44QzE5IDQuOCAyMC42IDMuNCAyMi44IDMuNEMyNSAzLjQgMjYuNiA0LjggMjYuNiA2LjhDMjYuNiA4LjggMjUgMTAuMiAyMi44IDEwLjJaIiBmaWxsPSIjNjc3MkU1Ii8+CjxwYXRoIGQ9Ik0xNy44IDMuNkgxNi42VjEwSDEzLjhWMy42SDEyLjZWMTBIMTEuNFYzLjZIMTAuMlYxMEg5VjMuNkg3LjhWMTBINi42VjMuNkg1LjRWMTBINFYzLjZIMi44VjEwSDEuNlYzLjZIMC40VjEwSDBWMTFIMTcuOFYzLjZaIiBmaWxsPSIjNjc3MkU1Ii8+Cjwvc3ZnPgo=" alt="Stripe" className="h-4" />
              </span>
            </span>
          </span>
          <div className="button-glow"></div>
        </button>

        <div className="flex justify-center items-center space-x-6 text-sm text-green-300/60">
          <div className="flex items-center space-x-2">
            <span>🔒</span>
            <span>Secure Payment</span>
          </div>
          <div className="flex items-center space-x-2">
            <span>⚡</span>
            <span>Instant Deployment</span>
          </div>
          <div className="flex items-center space-x-2">
            <span>🛡️</span>
            <span>No Subscription</span>
          </div>
        </div>
      </div>

      {showPaymentModal && (
        <PaymentModal onClose={() => setShowPaymentModal(false)} />
      )}

      {showSignIn && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="terminal-window max-w-md w-full">
            <div className="terminal-header">
              <span className="text-sm">auth-required.exe</span>
              <button onClick={() => setShowSignIn(false)} className="text-red-400 hover:text-red-300 text-xl">×</button>
            </div>
            <div className="terminal-body space-y-4">
              <div className="text-center">
                <h3 className="text-xl font-bold text-cyan-400 mb-2">SIGN IN REQUIRED</h3>
                <p className="text-green-300">Authentication needed to deploy agent</p>
              </div>
              <SignInForm />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
