import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Test the browser service
async function testBrowserService() {
  console.log('🧪 Testing Browser Automation Service...');
  
  // Start browser service in background
  console.log('🚀 Starting browser service...');
  const browserService = spawn('node', ['browser-service/server.js'], {
    env: {
      ...process.env,
      BROWSER_SERVICE_PORT: '3001',
      BROWSER_HEADLESS: 'true',
      DATA_DIR: './browser-service/data'
    },
    stdio: 'pipe'
  });

  // Wait for service to start
  await new Promise(resolve => setTimeout(resolve, 3000));

  try {
    // Test health endpoint
    console.log('🔍 Testing health endpoint...');
    const healthResponse = await fetch('http://localhost:3001/health');
    const healthData = await healthResponse.json();
    console.log('✅ Health check:', healthData);

    // Test browser initialization
    console.log('🌐 Testing browser initialization...');
    const initResponse = await fetch('http://localhost:3001/api/browser/init', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId: 'test-session-' + Date.now() })
    });
    const initData = await initResponse.json();
    console.log('✅ Browser init:', initData.success ? 'SUCCESS' : 'FAILED');

    if (initData.success) {
      // Test navigation
      console.log('🔗 Testing navigation...');
      const navResponse = await fetch('http://localhost:3001/api/browser/navigate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: initData.sessionId || 'test-session-' + Date.now(),
          url: 'https://example.com'
        })
      });
      const navData = await navResponse.json();
      console.log('✅ Navigation:', navData.success ? 'SUCCESS' : 'FAILED');

      // Test screenshot
      console.log('📸 Testing screenshot...');
      const screenshotResponse = await fetch('http://localhost:3001/api/browser/screenshot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: initData.sessionId || 'test-session-' + Date.now() })
      });
      const screenshotData = await screenshotResponse.json();
      console.log('✅ Screenshot:', screenshotData.success ? 'SUCCESS' : 'FAILED');
    }

    console.log('🎉 All tests completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    // Clean up
    console.log('🧹 Cleaning up...');
    browserService.kill();
  }
}

// Run tests
testBrowserService().catch(console.error);
