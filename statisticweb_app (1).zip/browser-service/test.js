import { chromium } from 'playwright';

async function testBrowserAutomation() {
  console.log('Testing Playwright browser automation...');
  
  try {
    // Test 1: Basic browser launch
    console.log('1. Testing browser launch...');
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();
    
    // Test 2: Navigation
    console.log('2. Testing navigation...');
    await page.goto('https://example.com');
    const title = await page.title();
    console.log(`   Page title: ${title}`);
    
    // Test 3: Screenshot
    console.log('3. Testing screenshot...');
    const screenshot = await page.screenshot({ type: 'png' });
    console.log(`   Screenshot size: ${screenshot.length} bytes`);
    
    // Test 4: Element interaction
    console.log('4. Testing element interaction...');
    const h1Text = await page.textContent('h1');
    console.log(`   H1 text: ${h1Text}`);
    
    // Test 5: JavaScript execution
    console.log('5. Testing JavaScript execution...');
    const result = await page.evaluate(() => {
      return {
        url: window.location.href,
        userAgent: navigator.userAgent,
        timestamp: Date.now()
      };
    });
    console.log(`   JS result: ${JSON.stringify(result, null, 2)}`);
    
    await browser.close();
    console.log('✅ All tests passed!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

// Test API endpoints
async function testAPIEndpoints() {
  console.log('\nTesting API endpoints...');
  
  try {
    const baseUrl = 'http://localhost:3001';
    
    // Test health endpoint
    console.log('1. Testing health endpoint...');
    const healthResponse = await fetch(`${baseUrl}/health`);
    const healthData = await healthResponse.json();
    console.log(`   Health status: ${healthData.status}`);
    
    // Test browser init
    console.log('2. Testing browser init...');
    const initResponse = await fetch(`${baseUrl}/api/browser/init`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId: 'test-session' })
    });
    const initData = await initResponse.json();
    console.log(`   Init success: ${initData.success}`);
    
    if (initData.success) {
      // Test navigation
      console.log('3. Testing navigation...');
      const navResponse = await fetch(`${baseUrl}/api/browser/navigate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: 'test-session',
          url: 'https://example.com'
        })
      });
      const navData = await navResponse.json();
      console.log(`   Navigation success: ${navData.success}`);
      
      // Test screenshot
      console.log('4. Testing screenshot...');
      const screenshotResponse = await fetch(`${baseUrl}/api/browser/screenshot`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: 'test-session' })
      });
      const screenshotData = await screenshotResponse.json();
      console.log(`   Screenshot success: ${screenshotData.success}`);
      
      // Test close session
      console.log('5. Testing session close...');
      const closeResponse = await fetch(`${baseUrl}/api/browser/close`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: 'test-session' })
      });
      const closeData = await closeResponse.json();
      console.log(`   Close success: ${closeData.success}`);
    }
    
    console.log('✅ API tests completed!');
    
  } catch (error) {
    console.error('❌ API test failed:', error);
  }
}

// Run tests
if (process.argv.includes('--api')) {
  testAPIEndpoints();
} else {
  testBrowserAutomation();
}
