import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  agents: defineTable({
    userId: v.id("users"),
    sessionId: v.string(),
    status: v.union(v.literal("active"), v.literal("inactive"), v.literal("expired")),
    expiresAt: v.number(),
    browserUrl: v.optional(v.string()),
    lastActivity: v.number(),
    tasksCompleted: v.number(),
    browserInitialized: v.optional(v.boolean()),
    proxyEndpoint: v.optional(v.string()),
  }).index("by_user", ["userId"])
    .index("by_session", ["sessionId"])
    .index("by_status", ["status"]),

  payments: defineTable({
    userId: v.id("users"),
    stripePaymentId: v.string(),
    amount: v.number(),
    status: v.union(v.literal("pending"), v.literal("completed"), v.literal("failed")),
    agentSessionId: v.optional(v.string()),
    stripeClientSecret: v.optional(v.string()),
  }).index("by_user", ["userId"])
    .index("by_stripe_id", ["stripePaymentId"]),

  tasks: defineTable({
    agentId: v.id("agents"),
    userId: v.id("users"),
    description: v.string(),
    status: v.union(v.literal("pending"), v.literal("running"), v.literal("completed"), v.literal("failed")),
    result: v.optional(v.string()),
    screenshot: v.optional(v.string()),
    executionTime: v.optional(v.number()),
  }).index("by_agent", ["agentId"])
    .index("by_user", ["userId"]),

  browserSessions: defineTable({
    sessionId: v.string(),
    agentId: v.id("agents"),
    status: v.union(v.literal("active"), v.literal("inactive"), v.literal("closed")),
    currentUrl: v.optional(v.string()),
    lastScreenshot: v.optional(v.string()),
    createdAt: v.number(),
    lastActivity: v.number(),
    proxyUrl: v.optional(v.string()),
  }).index("by_session", ["sessionId"])
    .index("by_agent", ["agentId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
