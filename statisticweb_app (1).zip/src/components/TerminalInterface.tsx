import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { BrowserViewer } from "./BrowserViewer";

interface TerminalInterfaceProps {
  agent: any;
}

export function TerminalInterface({ agent }: TerminalInterfaceProps) {
  const [command, setCommand] = useState("");
  const [history, setHistory] = useState<Array<{ type: 'command' | 'output' | 'error'; content: string; timestamp: number; screenshot?: string }>>([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [showBrowser, setShowBrowser] = useState(true);
  const terminalRef = useRef<HTMLDivElement>(null);
  
  const executeTask = useAction(api.agents.executeTask);
  const agentTasks = useQuery(api.agents.getAgentTasks, { agentId: agent._id });

  useEffect(() => {
    // Add welcome message
    setHistory([
      {
        type: 'output',
        content: `BROWSER AGENT INITIALIZED
Session ID: ${agent.sessionId}
Expires: ${new Date(agent.expiresAt).toLocaleString()}
Status: ACTIVE

Available commands:
  navigate <url>        - Navigate to a webpage
  click <selector>      - Click an element (CSS selector)
  type <text> in <sel>  - Type text into element
  extract <selector>    - Extract text from element
  screenshot           - Take a screenshot
  scroll <up|down>     - Scroll the page
  script <js>          - Execute JavaScript
  init                 - Initialize browser
  status              - Show browser status
  clear               - Clear terminal
  help                - Show this help

Example: navigate https://google.com
Example: click input[name="q"]
Example: type "hello world" in input[name="q"]`,
        timestamp: Date.now()
      }
    ]);
  }, [agent]);

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [history]);

  const handleCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim() || isExecuting) return;

    const newCommand = { type: 'command' as const, content: `$ ${command}`, timestamp: Date.now() };
    setHistory(prev => [...prev, newCommand]);

    if (command.toLowerCase() === 'help') {
      setHistory(prev => [...prev, {
        type: 'output',
        content: `Available commands:
  navigate <url>        - Navigate to a webpage
  click <selector>      - Click an element (CSS selector)
  type <text> in <sel>  - Type text into element
  extract <selector>    - Extract text from element
  screenshot           - Take a screenshot
  scroll <up|down>     - Scroll the page
  script <js>          - Execute JavaScript
  init                 - Initialize browser
  status              - Show browser status
  clear               - Clear terminal
  help                - Show this help

Examples:
  navigate https://google.com
  click input[name="q"]
  type "hello world" in input[name="q"]
  extract h1
  scroll down
  script document.title`,
        timestamp: Date.now()
      }]);
    } else if (command.toLowerCase() === 'clear') {
      setHistory([]);
    } else {
      setIsExecuting(true);
      try {
        const result = await executeTask({
          agentId: agent._id,
          task: command
        });
        
        setHistory(prev => [...prev, {
          type: 'output',
          content: result.result,
          timestamp: Date.now(),
          screenshot: result.screenshot
        }]);

        if (result.screenshot) {
          toast.success("Command executed successfully!");
        }
      } catch (error) {
        setHistory(prev => [...prev, {
          type: 'error',
          content: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
          timestamp: Date.now()
        }]);
        toast.error("Command failed");
      } finally {
        setIsExecuting(false);
      }
    }

    setCommand("");
  };

  const timeRemaining = Math.max(0, agent.expiresAt - Date.now());
  const hoursLeft = Math.floor(timeRemaining / (1000 * 60 * 60));
  const minutesLeft = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Left Column - Terminal */}
      <div className="space-y-6">
        {/* Agent Status Bar */}
        <div className="terminal-window">
          <div className="terminal-header">
            <div className="flex space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse delay-100"></div>
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse delay-200"></div>
            </div>
            <span className="text-sm">agent-status.sys</span>
          </div>
          <div className="terminal-body">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-cyan-400">STATUS:</span>
                <span className="ml-2 text-green-400">{agent.status.toUpperCase()}</span>
              </div>
              <div>
                <span className="text-cyan-400">TIME LEFT:</span>
                <span className="ml-2 text-yellow-400">{hoursLeft}h {minutesLeft}m</span>
              </div>
              <div>
                <span className="text-cyan-400">TASKS:</span>
                <span className="ml-2 text-purple-400">{agent.tasksCompleted}</span>
              </div>
              <div>
                <span className="text-cyan-400">SESSION:</span>
                <span className="ml-2 text-green-300 font-mono text-xs">{agent.sessionId.slice(-8)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Terminal */}
        <div className="terminal-window h-96">
          <div className="terminal-header">
            <div className="flex space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            </div>
            <span className="text-sm">browser-agent@terminal:~$</span>
          </div>
          
          <div className="terminal-body flex flex-col h-full">
            <div ref={terminalRef} className="flex-1 overflow-y-auto space-y-1 mb-4">
              {history.map((entry, index) => (
                <div key={index} className="space-y-2">
                  <div className={`font-mono text-sm ${
                    entry.type === 'command' ? 'text-green-400' :
                    entry.type === 'error' ? 'text-red-400' : 'text-green-300'
                  }`}>
                    <pre className="whitespace-pre-wrap">{entry.content}</pre>
                  </div>
                  {entry.screenshot && (
                    <div className="ml-4">
                      <img 
                        src={entry.screenshot} 
                        alt="Command result" 
                        className="max-w-full h-32 object-contain border border-green-400/30 rounded"
                      />
                    </div>
                  )}
                </div>
              ))}
              {isExecuting && (
                <div className="text-yellow-400 font-mono text-sm">
                  <span className="animate-pulse">Executing command...</span>
                </div>
              )}
            </div>
            
            <form onSubmit={handleCommand} className="flex items-center space-x-2">
              <span className="text-green-400 font-mono">$</span>
              <input
                type="text"
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                className="flex-1 bg-transparent border-none outline-none text-green-400 font-mono"
                placeholder="Enter command..."
                disabled={isExecuting}
                autoFocus
              />
            </form>
          </div>
        </div>

        {/* Recent Tasks */}
        {agentTasks && agentTasks.length > 0 && (
          <div className="terminal-window">
            <div className="terminal-header">
              <span className="text-sm">recent-tasks.log</span>
            </div>
            <div className="terminal-body">
              <div className="space-y-2">
                {agentTasks.slice(0, 5).map((task) => (
                  <div key={task._id} className="flex items-center justify-between text-sm">
                    <span className="text-green-300 truncate">{task.description}</span>
                    <span className={`px-2 py-1 rounded text-xs ${
                      task.status === 'completed' ? 'bg-green-400/20 text-green-400' :
                      task.status === 'failed' ? 'bg-red-400/20 text-red-400' :
                      'bg-yellow-400/20 text-yellow-400'
                    }`}>
                      {task.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Right Column - Browser Viewer */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-cyan-400">Live Browser View</h3>
          <button
            onClick={() => setShowBrowser(!showBrowser)}
            className="px-3 py-1 bg-cyan-400/20 text-cyan-400 border border-cyan-400/30 rounded hover:bg-cyan-400/30"
          >
            {showBrowser ? 'Hide' : 'Show'} Browser
          </button>
        </div>
        
        {showBrowser && <BrowserViewer agent={agent} />}
      </div>
    </div>
  );
}
