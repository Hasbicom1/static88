# 🔑 Quick Stripe Setup Guide

## The payment error occurs because you need REAL Stripe API keys. Here's how to fix it:

### Step 1: Get Stripe Test Keys (FREE)
1. **Go to**: https://stripe.com
2. **Sign up** for a free account (no credit card required for test mode)
3. **Go to**: Dashboard → Developers → API keys
4. **Copy these two keys**:
   - **Publishable key** (starts with `pk_test_`)
   - **Secret key** (starts with `sk_test_`)

### Step 2: Add Keys to Your Project

#### A. Frontend Key (.env.local file)
Replace this line in `/home/project/.env.local`:
```bash
# CHANGE THIS:
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_51234567890abcdef_REPLACE_WITH_YOUR_ACTUAL_PUBLISHABLE_KEY

# TO YOUR ACTUAL KEY:
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_YOUR_ACTUAL_PUBLISHABLE_KEY_HERE
```

#### B. Backend Key (Convex Dashboard)
1. **Go to**: https://dashboard.convex.dev/d/successful-ladybug-912
2. **Click**: Settings (gear icon)
3. **Click**: Environment Variables
4. **Add**: `STRIPE_SECRET_KEY` = `sk_test_YOUR_ACTUAL_SECRET_KEY_HERE`
5. **Click**: Save

### Step 3: Restart Development Server
```bash
# Stop the current server (Ctrl+C)
# Then restart:
npm run dev
```

### Step 4: Test Payment
- Use test card: **4242 4242 4242 4242**
- Any future expiry date (e.g., 12/25)
- Any 3-digit CVC (e.g., 123)

## ✅ That's it! 
Your payment system will now work with real Stripe integration.

## 🚨 Important Notes:
- These are **TEST keys** - no real money is charged
- Test keys are safe to use in development
- For production, you'll need to activate your Stripe account and use live keys
