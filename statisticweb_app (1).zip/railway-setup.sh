#!/bin/bash

# Railway Deployment Script for Agent.sys
echo "🚀 Deploying Agent.sys to Railway..."

# Check if Railway CLI is installed
if ! command -v railway &> /dev/null; then
    echo "❌ Railway CLI not found. Installing..."
    npm install -g @railway/cli
fi

# Login to Railway (if not already logged in)
echo "🔐 Checking Railway authentication..."
railway whoami || railway login

# Create new Railway project
echo "📦 Creating Railway project..."
railway new agent-sys-browser-automation

# Set environment variables
echo "⚙️  Setting environment variables..."

# Main app environment variables
railway variables set NODE_ENV=production
railway variables set PORT=3000
railway variables set BROWSER_SERVICE_URL=http://browser-service:3001
railway variables set CONVEX_DEPLOYMENT=successful-ladybug-912
railway variables set VITE_CONVEX_URL=https://successful-ladybug-912.convex.cloud

# Browser service environment variables
railway variables set BROWSER_HEADLESS=true
railway variables set DATA_DIR=/data
railway variables set BROWSER_SERVICE_PORT=3001

# Deploy the application
echo "🚀 Deploying to Railway..."
railway up

echo "✅ Deployment complete!"
echo "📊 Check your Railway dashboard for deployment status"
echo "🌐 Your app will be available at the Railway-provided URL"
