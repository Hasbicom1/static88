"use node";

import { action } from "./_generated/server";
import { v } from "convex/values";

// Browser automation using local Playwright service
const BROWSER_SERVICE_URL = process.env.BROWSER_SERVICE_URL || "http://localhost:3001";

async function callBrowserService(endpoint: string, data: any) {
  const response = await fetch(`${BROWSER_SERVICE_URL}/api/browser/${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data)
  });

  if (!response.ok) {
    throw new Error(`Browser service error: ${response.statusText}`);
  }

  return await response.json();
}

export const initializeBrowser = action({
  args: {
    sessionId: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const result = await callBrowserService('init', {
        sessionId: args.sessionId
      });
      
      return {
        success: result.success,
        screenshot: result.screenshot,
        url: result.url,
        title: result.title,
        message: 'Browser initialized successfully'
      };
    } catch (error) {
      console.error('Browser initialization error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  },
});

export const navigateToUrl = action({
  args: {
    sessionId: v.string(),
    url: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const result = await callBrowserService('navigate', {
        sessionId: args.sessionId,
        url: args.url
      });
      
      return {
        success: result.success,
        screenshot: result.screenshot,
        url: result.url,
        title: result.title,
        message: result.message
      };
    } catch (error) {
      console.error('Navigation error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Navigation failed'
      };
    }
  },
});

export const clickElement = action({
  args: {
    sessionId: v.string(),
    selector: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const result = await callBrowserService('click', {
        sessionId: args.sessionId,
        selector: args.selector
      });
      
      return {
        success: result.success,
        screenshot: result.screenshot,
        url: result.url,
        message: result.message
      };
    } catch (error) {
      console.error('Click error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Click failed'
      };
    }
  },
});

export const typeText = action({
  args: {
    sessionId: v.string(),
    selector: v.string(),
    text: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const result = await callBrowserService('type', {
        sessionId: args.sessionId,
        selector: args.selector,
        text: args.text
      });
      
      return {
        success: result.success,
        screenshot: result.screenshot,
        url: result.url,
        message: result.message
      };
    } catch (error) {
      console.error('Type error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Type failed'
      };
    }
  },
});

export const extractText = action({
  args: {
    sessionId: v.string(),
    selector: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const result = await callBrowserService('extract', {
        sessionId: args.sessionId,
        selector: args.selector
      });
      
      return {
        success: result.success,
        text: result.text,
        screenshot: result.screenshot,
        url: result.url,
        message: result.message
      };
    } catch (error) {
      console.error('Extract error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Extract failed'
      };
    }
  },
});

export const takeScreenshot = action({
  args: {
    sessionId: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const result = await callBrowserService('screenshot', {
        sessionId: args.sessionId
      });
      
      return {
        success: result.success,
        screenshot: result.screenshot,
        url: result.url,
        title: result.title,
        message: result.message
      };
    } catch (error) {
      console.error('Screenshot error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Screenshot failed'
      };
    }
  },
});

export const scrollPage = action({
  args: {
    sessionId: v.string(),
    direction: v.union(v.literal("up"), v.literal("down")),
    amount: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    try {
      const result = await callBrowserService('scroll', {
        sessionId: args.sessionId,
        direction: args.direction,
        amount: args.amount
      });
      
      return {
        success: result.success,
        screenshot: result.screenshot,
        url: result.url,
        message: result.message
      };
    } catch (error) {
      console.error('Scroll error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Scroll failed'
      };
    }
  },
});

export const executeScript = action({
  args: {
    sessionId: v.string(),
    script: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const result = await callBrowserService('script', {
        sessionId: args.sessionId,
        script: args.script
      });
      
      return {
        success: result.success,
        result: result.result,
        screenshot: result.screenshot,
        url: result.url,
        message: result.message
      };
    } catch (error) {
      console.error('Script execution error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Script execution failed'
      };
    }
  },
});

export const getBrowserStatus = action({
  args: {
    sessionId: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const result = await callBrowserService('status', {
        sessionId: args.sessionId
      });
      
      return {
        success: result.success,
        url: result.url,
        title: result.title,
        lastActivity: result.lastActivity,
        createdAt: result.createdAt,
        logsCount: result.logsCount
      };
    } catch (error) {
      console.error('Status error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Status check failed'
      };
    }
  },
});

export const closeBrowser = action({
  args: {
    sessionId: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const result = await callBrowserService('close', {
        sessionId: args.sessionId
      });
      
      return {
        success: result.success,
        message: result.message
      };
    } catch (error) {
      console.error('Close browser error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Close failed'
      };
    }
  },
});
