import { mutation, internalMutation, internalQuery, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const recordPayment = internalMutation({
  args: {
    userId: v.id("users"),
    stripePaymentId: v.string(),
    amount: v.number(),
    status: v.union(v.literal("pending"), v.literal("completed"), v.literal("failed")),
    stripeClientSecret: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("payments", args);
  },
});

export const updatePaymentStatus = internalMutation({
  args: {
    stripePaymentId: v.string(),
    status: v.union(v.literal("pending"), v.literal("completed"), v.literal("failed")),
  },
  handler: async (ctx, args) => {
    const payment = await ctx.db
      .query("payments")
      .withIndex("by_stripe_id", (q) => q.eq("stripePaymentId", args.stripePaymentId))
      .first();

    if (payment) {
      await ctx.db.patch(payment._id, {
        status: args.status,
      });
    }
  },
});

export const getPaymentByStripeId = internalQuery({
  args: {
    stripePaymentId: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("payments")
      .withIndex("by_stripe_id", (q) => q.eq("stripePaymentId", args.stripePaymentId))
      .first();
  },
});

export const getUserPayments = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("payments")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(10);
  },
});
