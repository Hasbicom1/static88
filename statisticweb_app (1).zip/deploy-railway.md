# Railway Deployment Instructions

## Quick Deploy

1. **Install Railway CLI:**
```bash
npm install -g @railway/cli
```

2. **Login to Railway:**
```bash
railway login
```

3. **Run deployment script:**
```bash
chmod +x railway-setup.sh
./railway-setup.sh
```

## Manual Deployment

### Step 1: Create Railway Project
```bash
railway new agent-sys-browser-automation
```

### Step 2: Set Environment Variables
```bash
# Main app variables
railway variables set NODE_ENV=production
railway variables set PORT=3000
railway variables set BROWSER_SERVICE_URL=http://browser-service:3001
railway variables set CONVEX_DEPLOYMENT=successful-ladybug-912
railway variables set VITE_CONVEX_URL=https://successful-ladybug-912.convex.cloud

# Browser service variables  
railway variables set BROWSER_HEADLESS=true
railway variables set DATA_DIR=/data
railway variables set BROWSER_SERVICE_PORT=3001
```

### Step 3: Deploy
```bash
railway up
```

## Verification

After deployment, verify the services:

1. **Check main app health:**
```bash
curl https://your-app.railway.app/health
```

2. **Check browser service status:**
```bash
curl https://your-app.railway.app/api/browser/status
```

3. **Test browser automation:**
```bash
curl -X POST https://your-app.railway.app/api/browser/init \
  -H "Content-Type: application/json" \
  -d '{"sessionId": "test-session"}'
```

## Production Monitoring

- Monitor memory usage (browser service needs 1GB+ RAM)
- Check logs for browser session cleanup
- Monitor response times for browser operations
- Set up alerts for service health failures

## Scaling Considerations

- Browser service is stateful (maintains sessions)
- Use sticky sessions for horizontal scaling
- Consider Redis for session storage in multi-instance setup
- Monitor concurrent browser session limits
