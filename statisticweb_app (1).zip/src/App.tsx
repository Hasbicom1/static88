import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { TerminalInterface } from "./components/TerminalInterface";
import { LandingPage } from "./components/LandingPage";

export default function App() {
  return (
    <div className="min-h-screen bg-black text-green-400 font-mono overflow-hidden">
      <div className="matrix-bg"></div>
      <div className="relative z-10">
        <header className="sticky top-0 z-20 bg-black/80 backdrop-blur-sm border-b border-green-400/30 p-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse delay-100"></div>
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse delay-200"></div>
              <span className="ml-4 text-green-400 font-bold">AGENT.SYS v2.1.0</span>
            </div>
            <Authenticated>
              <SignOutButton />
            </Authenticated>
          </div>
        </header>
        
        <main className="p-4">
          <Content />
        </main>
      </div>
      <Toaster theme="dark" />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const userAgent = useQuery(api.agents.getUserAgent);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="terminal-loader">
          <span>INITIALIZING SYSTEM...</span>
          <div className="loading-bar"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <Unauthenticated>
        <LandingPage />
      </Unauthenticated>
      
      <Authenticated>
        {userAgent ? (
          <TerminalInterface agent={userAgent} />
        ) : (
          <LandingPage />
        )}
      </Authenticated>
    </div>
  );
}
