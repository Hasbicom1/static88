"use node";

import { action } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";
import Stripe from "stripe";

// Initialize Stripe function
function getStripe() {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error("STRIPE_SECRET_KEY environment variable is required");
  }
  return new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2025-09-30.clover",
  });
}

export const createPaymentIntent = action({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    try {
      // Create real Stripe payment intent
      const stripe = getStripe();
      const paymentIntent = await stripe.paymentIntents.create({
        amount: 100, // $1.00 in cents
        currency: "usd",
        description: "Agent.sys - 24 Hour Browser Automation Access",
        metadata: {
          userId: userId,
          service: "browser-agent",
          duration: "24h"
        },
        automatic_payment_methods: {
          enabled: true,
        },
      });

      // Record payment in database
      await ctx.runMutation(internal.payments.recordPayment, {
        userId,
        stripePaymentId: paymentIntent.id,
        amount: 100,
        status: "pending",
        stripeClientSecret: paymentIntent.client_secret || undefined,
      });

      return {
        clientSecret: paymentIntent.client_secret,
        paymentId: paymentIntent.id,
      };
    } catch (error) {
      console.error('Payment intent creation failed:', error);
      throw new Error('Failed to create payment intent');
    }
  },
});

export const confirmPayment = action({
  args: {
    paymentId: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    try {
      // Get payment from database
      const payment = await ctx.runQuery(internal.payments.getPaymentByStripeId, {
        stripePaymentId: args.paymentId,
      });

      if (!payment) throw new Error("Payment not found");
      if (payment.userId !== userId) throw new Error("Unauthorized");

      // Update payment status to completed
      await ctx.runMutation(internal.payments.updatePaymentStatus, {
        stripePaymentId: args.paymentId,
        status: "completed",
      });

      return { success: true };
    } catch (error) {
      console.error('Payment confirmation failed:', error);
      throw new Error('Failed to confirm payment');
    }
  },
});

export const verifyPaymentWebhook = action({
  args: {
    signature: v.string(),
    payload: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET!;
      const stripe = getStripe();
      
      // Verify webhook signature
      const event = stripe.webhooks.constructEvent(
        args.payload,
        args.signature,
        endpointSecret
      );

      // Handle payment success
      if (event.type === 'payment_intent.succeeded') {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        
        // Update payment status in database
        await ctx.runMutation(internal.payments.updatePaymentStatus, {
          stripePaymentId: paymentIntent.id,
          status: "completed",
        });
      }

      // Handle payment failure
      if (event.type === 'payment_intent.payment_failed') {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        
        await ctx.runMutation(internal.payments.updatePaymentStatus, {
          stripePaymentId: paymentIntent.id,
          status: "failed",
        });
      }

      return { success: true };
    } catch (error) {
      console.error('Webhook verification failed:', error);
      throw new Error('Webhook verification failed');
    }
  },
});
