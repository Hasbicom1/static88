import { useState, useEffect, useRef } from "react";
import { useAction, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface BrowserViewerProps {
  agent: any;
}

export function BrowserViewer({ agent }: BrowserViewerProps) {
  const [screenshot, setScreenshot] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [browserUrl, setBrowserUrl] = useState("");
  const [autoRefresh, setAutoRefresh] = useState(true);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  
  const takeScreenshot = useAction(api.browser.takeScreenshot);
  const getBrowserStatus = useAction(api.browser.getBrowserStatus);
  const initializeBrowser = useAction(api.browser.initializeBrowser);

  const refreshScreenshot = async () => {
    if (isLoading) return;
    
    setIsLoading(true);
    try {
      const result = await takeScreenshot({ sessionId: agent.sessionId });
      if (result.success && result.screenshot) {
        setScreenshot(result.screenshot);
        setBrowserUrl((result as any).url || "");
      }
    } catch (error) {
      console.error("Screenshot error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const initBrowser = async () => {
    setIsLoading(true);
    try {
      const result = await initializeBrowser({ sessionId: agent.sessionId });
      if (result.success && result.screenshot) {
        setScreenshot(result.screenshot);
        setBrowserUrl((result as any).url || "");
      }
    } catch (error) {
      console.error("Browser init error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Initialize browser on mount
    if (!agent.browserInitialized) {
      initBrowser();
    } else {
      refreshScreenshot();
    }

    // Set up auto-refresh
    if (autoRefresh) {
      intervalRef.current = setInterval(refreshScreenshot, 3000); // Refresh every 3 seconds
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [agent.sessionId, autoRefresh]);

  useEffect(() => {
    if (autoRefresh) {
      intervalRef.current = setInterval(refreshScreenshot, 3000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [autoRefresh]);

  return (
    <div className="space-y-4">
      {/* Browser Controls */}
      <div className="terminal-window">
        <div className="terminal-header">
          <div className="flex space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          </div>
          <span className="text-sm">browser-viewer.sys</span>
        </div>
        <div className="terminal-body">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={refreshScreenshot}
                disabled={isLoading}
                className="px-3 py-1 bg-green-400/20 text-green-400 border border-green-400/30 rounded hover:bg-green-400/30 disabled:opacity-50"
              >
                {isLoading ? "Loading..." : "Refresh"}
              </button>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={autoRefresh}
                  onChange={(e) => setAutoRefresh(e.target.checked)}
                  className="form-checkbox text-green-400"
                />
                <span className="text-sm text-green-300">Auto-refresh</span>
              </label>
            </div>
            
            {browserUrl && (
              <div className="text-sm text-cyan-400 truncate max-w-md">
                URL: {browserUrl}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Browser Screenshot */}
      <div className="terminal-window">
        <div className="terminal-header">
          <span className="text-sm">Live Browser View</span>
          {isLoading && (
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
              <span className="text-xs text-yellow-400">Updating...</span>
            </div>
          )}
        </div>
        <div className="terminal-body p-0">
          {screenshot ? (
            <div className="relative">
              <img
                src={screenshot}
                alt="Browser Screenshot"
                className="w-full h-auto border border-green-400/30 rounded"
                style={{ maxHeight: '600px', objectFit: 'contain' }}
              />
              <div className="absolute top-2 right-2 bg-black/80 px-2 py-1 rounded text-xs text-green-400">
                Live View
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-96 text-green-300/60">
              <div className="text-center space-y-2">
                <div className="text-2xl">🌐</div>
                <div>Browser not initialized</div>
                <button
                  onClick={initBrowser}
                  disabled={isLoading}
                  className="px-4 py-2 bg-green-400/20 text-green-400 border border-green-400/30 rounded hover:bg-green-400/30 disabled:opacity-50"
                >
                  {isLoading ? "Initializing..." : "Initialize Browser"}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
