# Production Deployment Checklist

## Pre-Deployment
- [x] Convex backend deployed (successful-ladybug-912)
- [x] Browser service package.json created
- [x] Docker configurations ready
- [x] Railway configuration files prepared
- [x] Environment variables documented
- [x] Health check endpoints implemented

## Railway Deployment Steps

### 1. Install Railway CLI
```bash
npm install -g @railway/cli
railway login
```

### 2. Create Project and Deploy
```bash
# Option A: Automated
chmod +x railway-setup.sh
./railway-setup.sh

# Option B: Manual
railway new agent-sys-browser-automation
railway up
```

### 3. Set Environment Variables
In Railway dashboard or via CLI:
```bash
railway variables set NODE_ENV=production
railway variables set PORT=3000
railway variables set BROWSER_SERVICE_URL=http://browser-service:3001
railway variables set CONVEX_DEPLOYMENT=successful-ladybug-912
railway variables set VITE_CONVEX_URL=https://successful-ladybug-912.convex.cloud
railway variables set BROWSER_HEADLESS=true
railway variables set DATA_DIR=/data
railway variables set BROWSER_SERVICE_PORT=3001
```

### 4. Verify Deployment
```bash
# Test health endpoints
curl https://your-app.railway.app/health
curl https://your-app.railway.app/api/browser/status

# Run verification script
node verify-deployment.js https://your-app.railway.app
```

## Post-Deployment

### Monitoring Setup
- [ ] Configure Railway alerts
- [ ] Monitor memory usage (browser service needs 1GB+)
- [ ] Set up log aggregation
- [ ] Monitor response times

### Performance Optimization
- [ ] Enable Railway autoscaling if needed
- [ ] Configure session cleanup intervals
- [ ] Optimize browser launch parameters
- [ ] Set up CDN for static assets

### Security
- [ ] Review environment variables
- [ ] Enable HTTPS (automatic on Railway)
- [ ] Configure CORS policies
- [ ] Set up rate limiting

### Backup & Recovery
- [ ] Document rollback procedures
- [ ] Set up monitoring alerts
- [ ] Create incident response plan

## Production URLs
- **Main App**: https://your-app.railway.app
- **Health Check**: https://your-app.railway.app/health
- **Browser Status**: https://your-app.railway.app/api/browser/status
- **Convex Dashboard**: https://dashboard.convex.dev/d/successful-ladybug-912

## Support Contacts
- Railway Support: https://railway.app/help
- Convex Support: support@convex.dev
- Playwright Issues: https://github.com/microsoft/playwright/issues
