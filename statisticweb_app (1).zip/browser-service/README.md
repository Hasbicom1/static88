# Browser Automation Service

A production-ready Playwright-based browser automation service for Agent.sys.

## Features

- **Real Browser Automation**: Uses Playwright with Chromium for authentic web interactions
- **Session Management**: Handles multiple concurrent browser sessions
- **Screenshot Capture**: Automatic screenshot generation for all operations
- **Console Logging**: Captures browser console logs and errors
- **Resource Management**: Automatic cleanup of inactive sessions
- **Production Ready**: Includes Docker support and PM2 process management

## API Endpoints

### Health Check
```
GET /health
```

### Browser Operations
```
POST /api/browser/init          - Initialize browser session
POST /api/browser/navigate      - Navigate to URL
POST /api/browser/click         - Click element
POST /api/browser/type          - Type text into element
POST /api/browser/extract       - Extract text from element
POST /api/browser/screenshot    - Take screenshot
POST /api/browser/scroll        - Scroll page
POST /api/browser/script        - Execute JavaScript
POST /api/browser/status        - Get session status
POST /api/browser/close         - Close session
```

### Session Management
```
GET /api/browser/logs/:sessionId - Get session logs
```

## Development

```bash
# Install dependencies
cd browser-service
npm install

# Install Playwright browsers
npm run install-browsers

# Start development server
npm run dev

# Run tests
npm test
```

## Production Deployment

### Using Docker
```bash
# Build and run with Docker Compose
docker-compose up -d

# Or build manually
docker build -t browser-automation .
docker run -p 3001:3001 -v browser_data:/data browser-automation
```

### Using PM2
```bash
# Install PM2 globally
npm install -g pm2

# Start service
npm run start:browser

# Monitor
pm2 monit

# View logs
pm2 logs browser-automation
```

## Environment Variables

- `BROWSER_SERVICE_PORT`: Service port (default: 3001)
- `BROWSER_HEADLESS`: Run in headless mode (default: true)
- `DATA_DIR`: Directory for screenshots and logs (default: ./data)
- `NODE_ENV`: Environment (development/production)

## Testing

The service includes comprehensive tests:

```bash
# Test Playwright functionality
node test.js

# Test API endpoints (requires running service)
node test.js --api
```

## Architecture

- **Express.js**: Web server and API endpoints
- **Playwright**: Browser automation engine
- **Session Management**: In-memory session storage with cleanup
- **File Storage**: Screenshots and logs stored in configurable directory
- **Process Management**: PM2 for production process management
- **Containerization**: Docker support with health checks

## Security Features

- **Helmet.js**: Security headers
- **CORS**: Cross-origin resource sharing
- **Request Limits**: JSON payload size limits
- **Session Isolation**: Each session runs in isolated browser context
- **Resource Cleanup**: Automatic cleanup prevents memory leaks

## Monitoring

- Health check endpoint for load balancers
- Comprehensive logging with Morgan
- Session activity tracking
- Resource usage monitoring via PM2
