import { query, mutation, action, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";
import { api } from "./_generated/api";

export const getUserAgent = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const agent = await ctx.db
      .query("agents")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.neq(q.field("status"), "expired"))
      .first();

    return agent;
  },
});

export const createAgent = mutation({
  args: {
    paymentId: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Verify payment exists and is completed
    const payment = await ctx.db
      .query("payments")
      .withIndex("by_stripe_id", (q) => q.eq("stripePaymentId", args.paymentId))
      .first();

    if (!payment || payment.status !== "completed") {
      throw new Error("Payment not found or not completed");
    }

    const sessionId = `agent_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 hours

    const agentId = await ctx.db.insert("agents", {
      userId,
      sessionId,
      status: "active",
      expiresAt,
      lastActivity: Date.now(),
      tasksCompleted: 0,
      browserInitialized: false,
    });

    // Update payment with agent session
    await ctx.db.patch(payment._id, {
      agentSessionId: sessionId,
    });

    // Initialize browser session
    await ctx.scheduler.runAfter(0, internal.agents.initializeBrowserSession, {
      agentId,
      sessionId,
    });

    return { agentId, sessionId };
  },
});

export const initializeBrowserSession = internalMutation({
  args: {
    agentId: v.id("agents"),
    sessionId: v.string(),
  },
  handler: async (ctx, args) => {
    // This will be called by the scheduler to initialize the browser
    await ctx.db.patch(args.agentId, {
      browserInitialized: true,
      lastActivity: Date.now(),
    });
  },
});

export const executeTask = action({
  args: {
    agentId: v.id("agents"),
    task: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Get agent details
    const agent = await ctx.runQuery(api.agents.getAgentById, {
      agentId: args.agentId,
    });

    if (!agent || agent.userId !== userId) {
      throw new Error("Agent not found or unauthorized");
    }

    // Create task record
    const taskId = await ctx.runMutation(internal.agents.createTask, {
      agentId: args.agentId,
      userId,
      description: args.task,
    });

    try {
      // Parse and execute the command
      const result: any = await executeCommand(ctx, agent.sessionId, args.task);
      
      await ctx.runMutation(internal.agents.completeTask, {
        taskId,
        result: result.message || "Task completed successfully",
        screenshot: result.screenshot,
      });

      return { 
        success: true, 
        result: result.message || "Task completed successfully",
        screenshot: result.screenshot,
        url: result.url
      };
    } catch (error) {
      await ctx.runMutation(internal.agents.failTask, {
        taskId,
        error: error instanceof Error ? error.message : "Unknown error",
      });
      
      throw error;
    }
  },
});

async function executeCommand(ctx: any, sessionId: string, command: string): Promise<any> {
  const parts = command.trim().split(' ');
  const action = parts[0].toLowerCase();
  
  switch (action) {
    case 'navigate':
    case 'goto':
      const url = parts.slice(1).join(' ');
      if (!url) throw new Error("URL required for navigate command");
      return await ctx.runAction(api.browser.navigateToUrl, { sessionId, url });
      
    case 'click':
      const clickSelector = parts.slice(1).join(' ');
      if (!clickSelector) throw new Error("Selector required for click command");
      return await ctx.runAction(api.browser.clickElement, { sessionId, selector: clickSelector });
      
    case 'type':
      const typeArgs = parts.slice(1).join(' ').split(' in ');
      if (typeArgs.length !== 2) throw new Error("Format: type <text> in <selector>");
      const [text, selector] = typeArgs;
      return await ctx.runAction(api.browser.typeText, { sessionId, selector: selector.trim(), text: text.trim() });
      
    case 'extract':
      const extractSelector = parts.slice(1).join(' ');
      if (!extractSelector) throw new Error("Selector required for extract command");
      const extractResult: any = await ctx.runAction(api.browser.extractText, { sessionId, selector: extractSelector });
      return { ...extractResult, message: `Extracted text: ${extractResult.text}` };
      
    case 'screenshot':
      return await ctx.runAction(api.browser.takeScreenshot, { sessionId });
      
    case 'scroll':
      const direction = parts[1] || 'down';
      const amount = parts[2] ? parseInt(parts[2]) : undefined;
      return await ctx.runAction(api.browser.scrollPage, { sessionId, direction, amount });
      
    case 'script':
    case 'execute':
      const script = parts.slice(1).join(' ');
      if (!script) throw new Error("Script required for execute command");
      return await ctx.runAction(api.browser.executeScript, { sessionId, script });
      
    case 'init':
    case 'initialize':
      return await ctx.runAction(api.browser.initializeBrowser, { sessionId });
      
    case 'status':
      return await ctx.runAction(api.browser.getBrowserStatus, { sessionId });
      
    default:
      throw new Error(`Unknown command: ${action}. Available commands: navigate, click, type, extract, screenshot, scroll, script, init, status`);
  }
}

export const getAgentById = query({
  args: {
    agentId: v.id("agents"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.agentId);
  },
});

export const createTask = internalMutation({
  args: {
    agentId: v.id("agents"),
    userId: v.id("users"),
    description: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("tasks", {
      agentId: args.agentId,
      userId: args.userId,
      description: args.description,
      status: "pending",
    });
  },
});

export const completeTask = internalMutation({
  args: {
    taskId: v.id("tasks"),
    result: v.string(),
    screenshot: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.taskId, {
      status: "completed",
      result: args.result,
      screenshot: args.screenshot,
    });

    // Update agent task count
    const task = await ctx.db.get(args.taskId);
    if (task) {
      const agent = await ctx.db.get(task.agentId);
      if (agent) {
        await ctx.db.patch(task.agentId, {
          tasksCompleted: agent.tasksCompleted + 1,
          lastActivity: Date.now(),
        });
      }
    }
  },
});

export const failTask = internalMutation({
  args: {
    taskId: v.id("tasks"),
    error: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.taskId, {
      status: "failed",
      result: `Error: ${args.error}`,
    });
  },
});

export const getAgentTasks = query({
  args: {
    agentId: v.id("agents"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("tasks")
      .withIndex("by_agent", (q) => q.eq("agentId", args.agentId))
      .order("desc")
      .take(10);
  },
});

export const expireAgent = internalMutation({
  args: {
    agentId: v.id("agents"),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.agentId, {
      status: "expired",
    });
  },
});
