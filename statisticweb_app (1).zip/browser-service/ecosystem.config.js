export default {
  apps: [{
    name: 'browser-automation',
    script: 'server.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      BROWSER_SERVICE_PORT: 3001,
      BROWSER_HEADLESS: 'true',
      DATA_DIR: '/data'
    },
    env_development: {
      NODE_ENV: 'development',
      BROWSER_SERVICE_PORT: 3001,
      BROWSER_HEADLESS: 'false',
      DATA_DIR: './data'
    },
    error_file: '/data/logs/browser-service-error.log',
    out_file: '/data/logs/browser-service-out.log',
    log_file: '/data/logs/browser-service.log',
    time: true
  }]
};
